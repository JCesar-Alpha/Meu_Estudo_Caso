export const API_BASE_URL = 'https://proweb.leoproti.com.br';

export const CURSOS = {
  CC: 'Ciência da Computação',
  ES: 'Engenharia de Software',
  SI: 'Sistemas de Informação',
  ADM: 'Administração',
  DG: 'Design Gráfico'
};

export const CURSO_LABELS = {
  CC: 'Ciência da Computação',
  ES: 'Engenharia de Software',
  SI: 'Sistemas de Informação',
  ADM: 'Administração',
  DG: 'Design Gráfico'
};

export const COLORS = {
  PRIMARY: '#007AFF',
  SUCCESS: '#4CAF50',
  ERROR: '#F44336',
  WARNING: '#FF9800',
  INFO: '#2196F3',
  LIGHT_GRAY: '#F5F5F5',
  DARK_GRAY: '#333333'
};

export const SCREENS = {
  HOME: 'Home',
  ALUNO_DETAILS: 'AlunoDetails',
  NOT_FOUND: 'NotFound'
};